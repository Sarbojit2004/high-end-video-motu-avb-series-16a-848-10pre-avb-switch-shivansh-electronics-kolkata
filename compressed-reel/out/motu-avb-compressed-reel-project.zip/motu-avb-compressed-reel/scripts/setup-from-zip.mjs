// Stages the bundled assets/ folder into public/ so the project renders
// without the parent repository (music excepted — see OFFLINE-SETUP.md).
import { cpSync, mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
const P = resolve(dirname(fileURLToPath(import.meta.url)), "..");
mkdirSync(resolve(P, "public/audio"), { recursive: true });
cpSync(resolve(P, "assets/images"), resolve(P, "public/images"), { recursive: true });
cpSync(resolve(P, "assets/fonts"), resolve(P, "public/fonts"), { recursive: true });
cpSync(resolve(P, "assets/sfx"), resolve(P, "public/audio/sfx"), { recursive: true });
console.log("staged images, fonts and sfx into public/. Next: node scripts/make-music.mjs");
