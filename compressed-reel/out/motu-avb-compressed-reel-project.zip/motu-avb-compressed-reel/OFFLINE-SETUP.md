# Rendering from this zip

    npm install
    node scripts/setup-from-zip.mjs
    npm run render     # or render:reel2 / render:reel3

`assets/` already holds the render-ready images, the two ported woff2 font
families and the 34 synthesized SFX files, so those need no network and no
sibling repository.

The one thing not bundled is the music: the five instrumental tracks and their
17 stems are 100 MB, and this zip is committed inside the repository that
already ships them under `sound-effects/`. Duplicating them would push the zip
past GitHub's 100 MB per-file limit for no benefit. Point `scripts/make-music.mjs`
at that folder (it looks for `../sound-effects` by default) and run:

    node scripts/make-music.mjs

Then `npm run render` reproduces the master, and `npm run render:audio`
reproduces the two standalone audio deliverables.
